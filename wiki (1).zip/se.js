const http = require('http');
var server = http.createServer(function(req,res){
    res.redirect('https://geunyang.ga'+req.url);
});
server.listen(80);
